
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import PropertyCard from '@/components/PropertyCard';
import HeroImage from '@/components/HeroImage';
import CallToAction from '@/components/CallToAction';

const Home = () => {
  const whatsappMessage = encodeURIComponent(
    "أهلاً وسهلاً بك في أبو سلطان لعقارات المدينة المنورة 🏠 تفضل، سيتم الرد عليك بأسرع وقت ممكن. انتظاركم محل اهتمامنا"
  );
  const whatsappLink = `https://wa.me/966530006190?text=${whatsappMessage}`;

  const properties = [
    {
      image: 'https://images.unsplash.com/photo-1529405730888-1e9ce6b74bc3',
      title: 'شقق تمليك',
      description: 'تصاميم عصرية ومساحات متنوعة تناسب احتياجاتك في أرقى الأحياء',
      icon: '🏢'
    },
    {
      image: 'https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf',
      title: 'فلل فاخرة',
      description: 'بناء شخصي وضمانات شاملة مع أعلى معايير الجودة والتصميم',
      icon: '🏠'
    },
    {
      image: 'https://images.unsplash.com/photo-1619842799356-06c1c91c9d18',
      title: 'عمائر سكنية',
      description: 'فرص استثمارية بعوائد مجزية ومواقع مميزة للباحثين عن الدخل المستدام',
      icon: '🏙️'
    },
    {
      image: 'https://images.unsplash.com/photo-1673551798121-9d7787c41c63',
      title: 'أراضي سكنية وتجارية',
      description: 'مواقع استراتيجية ومستقبل واعد للاستثمار والتطوير العقاري',
      icon: '🏞️'
    },
    {
      image: 'https://images.unsplash.com/photo-1605989287045-4bb5808fe1f4',
      title: 'شقق سكنية إيجار',
      description: 'خيارات مريحة في أفضل أحياء المدينة تناسب جميع العائلات',
      icon: '🔑'
    },
    {
      image: 'https://images.unsplash.com/photo-1628123131344-5b6b9719c759',
      title: 'محلات ومعارض تجارية',
      description: 'مواقع حيوية لانطلاق أعمالك وتوسيع نشاطك التجاري',
      icon: '🏪'
    }
  ];

  const titleWords = ["أبو", "سلطان", "عقارات", "المدينة"];

  return (
    <>
      <Helmet>
        <title>أبو سلطان عقارات المدينة المنورة | استثمار عقاري موثوق</title>
        <meta name="description" content="أبو سلطان عقارات المدينة المنورة - متخصصون في بيع وتأجير الشقق والفلل والعمائر والأراضي. نلبي طموحك في السكن والاستثمار." />
      </Helmet>

      <div className="bg-background overflow-hidden">
        {/* Hero Section */}
        <section id="hero" className="relative min-h-screen flex items-center justify-center pt-20">
          <HeroImage />
          
          <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center" dir="rtl">
            <h1 className="flex flex-wrap justify-center gap-x-4 text-5xl md:text-7xl lg:text-8xl font-extrabold text-white mb-6 leading-tight drop-shadow-2xl">
              {titleWords.map((word, i) => (
                <motion.span
                  key={i}
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: i * 0.15, ease: [0.2, 0.65, 0.3, 0.9] }}
                  className={i >= 2 ? "text-primary" : ""}
                >
                  {word}
                </motion.span>
              ))}
            </h1>
            
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.8, ease: "easeOut" }}
              className="text-xl md:text-3xl text-white/90 mb-12 leading-relaxed max-w-3xl mx-auto font-light drop-shadow-md"
            >
              نلبي طموحك في السكن والاستثمار في المدينة المنورة
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 1.2 }}
            >
              <CallToAction text="استشرنا الآن مجاناً" href={whatsappLink} />
            </motion.div>
          </div>
          
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2, duration: 1 }}
            className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10 animate-bounce"
          >
            <div className="w-8 h-12 rounded-full border-2 border-white/50 flex justify-center pt-2">
              <div className="w-1.5 h-3 bg-primary rounded-full" />
            </div>
          </motion.div>
        </section>

        {/* Services / Properties Section */}
        <section id="services" className="py-24 md:py-32 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" dir="rtl">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8 }}
              className="text-center mb-20"
            >
              <span className="text-primary font-bold tracking-widest uppercase text-sm mb-4 block">خدماتنا المتميزة</span>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-secondary mb-6">
                الخيارات العقارية
              </h2>
              <div className="w-24 h-1.5 bg-primary mx-auto rounded-full mb-6" />
              <p className="text-xl text-secondary/70 max-w-3xl mx-auto leading-relaxed">
                نقدم لك مجموعة متنوعة من الخيارات العقارية المنتقاة بعناية لتحقيق أهدافك السكنية والاستثمارية
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12">
              {properties.map((property, index) => (
                <PropertyCard
                  key={index}
                  image={property.image}
                  title={property.title}
                  description={property.description}
                  icon={property.icon}
                  index={index}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Contact CTA Section */}
        <section id="contact" className="py-32 relative overflow-hidden">
          <div className="absolute inset-0 bg-secondary z-0" />
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1506851321937-51fff21bc9a0')] opacity-10 bg-cover bg-center mix-blend-overlay z-0" />
          
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10" dir="rtl">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-12 md:p-20 shadow-2xl"
            >
              <span className="text-3xl mb-6 block">📍</span>
              <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-8 leading-tight">
                هل تبحث عن عقارك المثالي في <span className="text-primary">المدينة المنورة</span>؟
              </h2>
              <p className="text-xl text-white/80 mb-12 font-light leading-relaxed">
                فريقنا من الخبراء العقاريين جاهز لخدمتك وتقديم أفضل الحلول التي تناسب ميزانيتك وتطلعاتك. دعنا نساعدك في اتخاذ القرار الصحيح.
              </p>
              
              <CallToAction text="تواصل معنا عبر الواتساب الآن" href={whatsappLink} />
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;
