
import React, { useState } from 'react';
import { motion } from 'framer-motion';

const PropertyCard = ({ image, title, description, icon, index }) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  
  const whatsappMessage = encodeURIComponent(
    `أهلاً وسهلاً بك في أبو سلطان لعقارات المدينة المنورة 🏠 أريد الاستفسار عن: ${title}`
  );
  const whatsappLink = `https://wa.me/966530006190?text=${whatsappMessage}`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.6, delay: index * 0.1, ease: "easeOut" }}
      className="group bg-card rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden hover:-translate-y-2 border border-border relative"
      dir="rtl"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-0 pointer-events-none" />
      
      <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="block relative z-10">
        <div className="relative h-64 overflow-hidden rounded-t-2xl bg-muted">
          {!imageLoaded && <div className="absolute inset-0 animate-shimmer" />}
          <img
            src={image}
            alt={title}
            onLoad={() => setImageLoaded(true)}
            className={`w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-secondary/90 via-secondary/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-300" />
          <div className="absolute bottom-4 right-4 bg-primary/90 backdrop-blur-sm text-secondary p-3 rounded-full shadow-lg transform group-hover:scale-110 transition-transform duration-300">
            <span className="text-2xl" role="img" aria-label="icon">{icon}</span>
          </div>
        </div>
      </a>
      
      <div className="p-6 space-y-4 relative z-10 bg-card">
        <h3 className="text-2xl font-bold text-secondary group-hover:text-primary transition-colors duration-300">{title}</h3>
        <p className="text-muted-foreground leading-relaxed">{description}</p>
        
        <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="block mt-6">
          <button className="w-full bg-secondary/5 hover:bg-primary text-secondary hover:text-primary-foreground font-bold rounded-xl py-4 transition-all duration-300 border border-secondary/10 hover:border-primary group-hover:shadow-[0_4px_14px_rgba(212,175,55,0.3)] flex items-center justify-center gap-2">
            <span>استفسر الآن</span>
            <span className="text-xl">📱</span>
          </button>
        </a>
      </div>
    </motion.div>
  );
};

export default PropertyCard;
