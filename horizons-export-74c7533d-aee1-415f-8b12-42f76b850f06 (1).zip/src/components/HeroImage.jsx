
import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

const HeroImage = () => {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 1000], [0, 300]);

  return (
    <div className="absolute inset-0 z-0 overflow-hidden w-full h-full">
      <motion.div
        style={{ y }}
        className="w-full h-[120%] -top-[10%] relative"
      >
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1506851321937-51fff21bc9a0')"
          }}
        />
        <div className="absolute inset-0 bg-secondary/70 backdrop-blur-[2px]" />
      </motion.div>
    </div>
  );
};

export default HeroImage;
