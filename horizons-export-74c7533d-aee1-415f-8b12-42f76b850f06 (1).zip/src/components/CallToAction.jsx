
import React from 'react';
import { motion } from 'framer-motion';

const CallToAction = ({ text, href, onClick, className = '' }) => {
  const Component = href ? motion.a : motion.button;
  const props = href ? { href, target: "_blank", rel: "noopener noreferrer" } : { onClick };

  return (
    <Component
      {...props}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className={`relative overflow-hidden inline-flex items-center justify-center gap-2 bg-gradient-to-r from-primary to-[#b8952b] text-secondary font-bold text-xl px-12 py-5 rounded-full shadow-[0_4px_20px_rgba(212,175,55,0.4)] hover:shadow-[0_8px_30px_rgba(212,175,55,0.6)] transition-all duration-300 group ${className}`}
    >
      <span className="relative z-10 flex items-center gap-2">
        {text}
      </span>
      <motion.div
        className="absolute inset-0 bg-white/20"
        initial={{ scale: 0, opacity: 0 }}
        whileHover={{ scale: 2, opacity: 1 }}
        transition={{ duration: 0.5 }}
        style={{ borderRadius: "100%" }}
      />
    </Component>
  );
};

export default CallToAction;
