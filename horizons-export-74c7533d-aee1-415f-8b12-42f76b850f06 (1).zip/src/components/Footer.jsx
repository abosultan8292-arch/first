
import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, MapPin, Phone } from 'lucide-react';
import Logo from './Logo';

const Footer = () => {
  const whatsappMessage = encodeURIComponent(
    "أهلاً وسهلاً بك في أبو سلطان لعقارات المدينة المنورة 🏠 تفضل، سيتم الرد عليك بأسرع وقت ممكن. انتظاركم محل اهتمامنا"
  );
  const whatsappLink = `https://wa.me/966530006190?text=${whatsappMessage}`;

  return (
    <footer className="bg-secondary text-white border-t-4 border-primary mt-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1506851321937-51fff21bc9a0')] opacity-5 bg-cover bg-center mix-blend-overlay z-0" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="flex flex-col items-center justify-center text-center space-y-10" 
          dir="rtl"
        >
          
          <div className="bg-white/5 p-6 rounded-2xl backdrop-blur-sm border border-white/10 inline-block">
             <Logo className="filter brightness-0 invert" />
          </div>

          <p className="text-xl text-white/80 max-w-2xl mx-auto leading-relaxed font-light">
            متخصصون في عقارات المدينة المنورة. نلبي طموحك في السكن والاستثمار بأعلى معايير الجودة والاحترافية والشفافية التامة.
          </p>

          <div className="flex flex-wrap justify-center gap-6 mt-8">
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 bg-primary text-secondary hover:bg-[#b8952b] px-8 py-4 rounded-full transition-all duration-300 font-bold text-lg hover:shadow-[0_0_25px_rgba(212,175,55,0.4)] hover:-translate-y-1 group"
            >
              <MessageCircle className="w-6 h-6 group-hover:rotate-12 transition-transform" />
              <span dir="ltr">+966 53 000 6190</span>
            </a>
            
            <div className="inline-flex items-center gap-3 bg-white/10 border border-white/20 text-white px-8 py-4 rounded-full font-medium text-lg cursor-default">
              <MapPin className="w-6 h-6 text-primary" />
              <span>المدينة المنورة، المملكة العربية السعودية</span>
            </div>
          </div>

        </motion.div>

        <div className="mt-20 pt-8 border-t border-white/10 relative z-10">
          <div className="flex justify-center items-center">
            <p className="text-sm text-white/50 text-center font-medium tracking-wide" dir="rtl">
              © 2026 أبو سلطان عقارات المدينة المنورة. جميع الحقوق محفوظة.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
