
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MessageCircle } from 'lucide-react';
import Logo from './Logo';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (e, id) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const whatsappMessage = encodeURIComponent("أهلاً وسهلاً بك في أبو سلطان لعقارات المدينة المنورة 🏠");
  const whatsappLink = `https://wa.me/966530006190?text=${whatsappMessage}`;

  return (
    <header 
      className={`fixed top-0 w-full z-50 transition-all duration-500 border-b ${
        isScrolled 
          ? 'bg-white/95 backdrop-blur-md shadow-md border-border py-2' 
          : 'bg-transparent border-transparent py-4'
      }`} 
      dir="rtl"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <a href="#hero" onClick={(e) => scrollToSection(e, 'hero')} className="cursor-pointer">
            <Logo />
          </a>

          <nav className="hidden md:flex items-center space-x-8 space-x-reverse">
            {[
              { label: 'الرئيسية', id: 'hero' },
              { label: 'خدماتنا', id: 'services' },
              { label: 'تواصل معنا', id: 'contact' }
            ].map((link) => (
              <a
                key={link.id}
                href={`#${link.id}`}
                onClick={(e) => scrollToSection(e, link.id)}
                className={`relative font-semibold text-lg overflow-hidden group ${
                  isScrolled ? 'text-secondary' : 'text-white'
                } hover:text-primary transition-colors duration-300`}
              >
                {link.label}
                <span className="absolute bottom-0 right-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          <motion.a
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className={`hidden sm:flex items-center gap-2 px-6 py-2.5 rounded-full font-bold transition-all duration-300 ${
              isScrolled
                ? 'bg-primary text-secondary hover:bg-[#b8952b] shadow-md'
                : 'bg-white text-secondary hover:bg-primary hover:text-white shadow-lg'
            }`}
          >
            <MessageCircle className="w-5 h-5" />
            <span>واتساب</span>
          </motion.a>
        </div>
      </div>
    </header>
  );
};

export default Header;
