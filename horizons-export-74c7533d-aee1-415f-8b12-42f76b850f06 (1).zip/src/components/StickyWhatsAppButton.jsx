
import React from 'react';
import { MessageCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const StickyWhatsAppButton = () => {
  const whatsappMessage = encodeURIComponent(
    "أهلاً وسهلاً بك في أبو سلطان لعقارات المدينة المنورة 🏠 تفضل، سيتم الرد عليك بأسرع وقت ممكن. انتظاركم محل اهتمامنا"
  );
  const whatsappLink = `https://wa.me/966530006190?text=${whatsappMessage}`;

  return (
    <motion.a
      href={whatsappLink}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex items-center gap-3 bg-primary text-primary-foreground px-6 py-4 rounded-full shadow-[0_4px_15px_rgba(212,175,55,0.4)] hover:shadow-[0_0_25px_rgba(212,175,55,0.8)] transition-all duration-300 hover:scale-110 animate-pulse-glow group"
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay: 1 }}
      dir="rtl"
    >
      <MessageCircle className="w-7 h-7 group-hover:rotate-12 transition-transform duration-300" />
      <span className="font-semibold hidden sm:block text-lg">تواصل معنا</span>
    </motion.a>
  );
};

export default StickyWhatsAppButton;
