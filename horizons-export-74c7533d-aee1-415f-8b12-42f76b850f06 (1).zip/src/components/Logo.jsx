
import React from 'react';
import { motion } from 'framer-motion';

const Logo = ({ className = '' }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
      className={`flex items-center gap-3 ${className}`}
      dir="rtl"
    >
      <div className="relative flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-[#b8952b] shadow-lg">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-7 h-7 text-white"
        >
          <path d="M3 21h18" />
          <path d="M9 8h1" />
          <path d="M9 12h1" />
          <path d="M9 16h1" />
          <path d="M14 8h1" />
          <path d="M14 12h1" />
          <path d="M14 16h1" />
          <path d="M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16" />
        </svg>
      </div>
      <div className="flex flex-col">
        <span className="text-xl md:text-2xl font-extrabold tracking-tight text-secondary leading-none">
          أبو سلطان
        </span>
        <span className="text-xs font-semibold tracking-widest text-primary uppercase mt-1">
          Abu Sultan Real Estate
        </span>
      </div>
    </motion.div>
  );
};

export default Logo;
