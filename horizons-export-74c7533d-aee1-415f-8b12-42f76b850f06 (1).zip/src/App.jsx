
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Home from '@/pages/Home';
import ScrollToTop from '@/components/ScrollToTop';
import StickyWhatsAppButton from '@/components/StickyWhatsAppButton';

function App() {
  return (
    <div className="min-h-screen flex flex-col bg-background font-sans">
      <ScrollToTop />
      <Header />
      <StickyWhatsAppButton />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;
